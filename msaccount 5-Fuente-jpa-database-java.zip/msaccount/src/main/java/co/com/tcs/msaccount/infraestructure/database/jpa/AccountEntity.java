package co.com.tcs.msaccount.infraestructure.database.jpa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@IdClass(AccountPK.class)
@Table(name = "tbl_account")
public class AccountEntity {
    @Id private String type;
    @Id private long number;
    @Column private Double balance;
    @Column private Boolean status;
    @Column(name = "date_creation") private String dateCreation;
    @Column(name = "user_creation") private String userCreation;
}
