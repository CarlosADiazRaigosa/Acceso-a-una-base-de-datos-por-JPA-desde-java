package co.com.tcs.msaccount.infraestructure.database;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.sql.*;

@Builder
public class Database {
    private String connectionUrl;
    private String user;
    private String password;
    @Getter
    private Connection conn;
    @Setter @Getter
    private PreparedStatement ps;
    @Setter @Getter
    private CallableStatement cs;

    public void createConnection() throws SQLException {
        this.conn = DriverManager.getConnection(
                new String("jdbc:mysql://tcsinnovation.ch05om7hlkfd.us-east-1.rds.amazonaws.com:3306/internal_training?serverTimezone=UTC"),
                new String("training_user_cnx"),
                new String("pwd_training_user_cnx"));
    }

    public void closeConnection() throws SQLException {
        if(!this.conn.isClosed()){
            this.conn.close();
        }
    }
}
