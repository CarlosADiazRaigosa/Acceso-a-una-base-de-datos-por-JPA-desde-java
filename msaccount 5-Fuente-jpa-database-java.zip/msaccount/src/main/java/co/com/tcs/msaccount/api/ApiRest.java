package co.com.tcs.msaccount.api;

import co.com.tcs.msaccount.api.contracts.AccountResponse;
import co.com.tcs.msaccount.infraestructure.adapter.AccountAdapter;
import co.com.tcs.msaccount.model.Account;
import co.com.tcs.msaccount.usecase.AccountUseCase;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/msaccount", produces = MediaType.APPLICATION_JSON_VALUE)
public class ApiRest {
    @GetMapping("/getById")
    public ResponseEntity<AccountResponse> getById(@RequestParam String type, @RequestParam long number){
        return AccountUseCase.builder().build().queryAccountById(type, number);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Account>> getAll(){
        return AccountUseCase.builder().build().queryAllAccount();
    }

    @PostMapping("/create")
    public ResponseEntity<AccountResponse> createAccount(@RequestBody Account account){
        // To do call use case
        return AccountUseCase.builder().build().create(account);
    }
}
