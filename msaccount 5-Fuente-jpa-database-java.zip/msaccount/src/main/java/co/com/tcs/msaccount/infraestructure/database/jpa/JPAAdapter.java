package co.com.tcs.msaccount.infraestructure.database.jpa;

import org.springframework.data.repository.CrudRepository;

public interface JPAAdapter extends CrudRepository<AccountEntity, AccountPK> {
}
