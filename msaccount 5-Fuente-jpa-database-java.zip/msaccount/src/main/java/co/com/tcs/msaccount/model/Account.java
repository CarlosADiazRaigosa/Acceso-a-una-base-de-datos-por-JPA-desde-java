package co.com.tcs.msaccount.model;

import lombok.*;

@Builder
@Data
public class Account {
    private String type;
    private long number;
    private Double balance;
    private Boolean status;
    private String dateCreation;
    private String userCreation;
}
